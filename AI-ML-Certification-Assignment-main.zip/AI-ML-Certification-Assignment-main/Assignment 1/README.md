# Assignment 1: Numpy Basics

This directory contains the code and documentation for my Numpy basics assignment. The `Numpy Exercise.ipynb` notebook covers array creation, indexing, slicing, and broadcasting using Numpy.
